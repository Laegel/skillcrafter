<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="ob_00024_" tilewidth="140" tileheight="138" tilecount="1" columns="1">
 <image source="ob_00024_.png" width="140" height="138"/>
</tileset>
