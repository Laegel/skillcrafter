<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="bg_00250_" tilewidth="140" tileheight="157" tilecount="1" columns="1">
 <tileoffset x="-7" y="94"/>
 <image source="bg_00250_.png" width="140" height="157"/>
</tileset>
